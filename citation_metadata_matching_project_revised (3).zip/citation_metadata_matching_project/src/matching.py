import re
import html
from urllib.parse import urlparse
from rapidfuzz import fuzz, process
import pandas as pd

ARXIV_RE = re.compile(r"(?:arxiv\.org/(?:abs|pdf)/)([0-9]{4}\.[0-9]{4,5}|[a-z\-]+/[0-9]{7})", re.I)

def clean_text(s):
    s = html.unescape(str(s or "")).lower()
    s = re.sub(r"<[^>]+>", " ", s)
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()

def parse_citation(raw):
    """Parse benchmark markdown citation: [authors, year, title](URL)."""
    raw = str(raw or "").strip()
    m = re.search(r"\[([^\]]+)\]\((https?://[^)]+)\)", raw)
    if m:
        body, url = m.group(1), m.group(2)
    else:
        body, url = raw, ""
    parts = [p.strip() for p in body.split(",", 2)]
    authors, year, title = "", None, ""
    if len(parts) >= 3:
        authors = parts[0]
        y = re.search(r"\b(18|19|20|21)\d{2}\b", parts[1])
        year = int(y.group(0)) if y else None
        title = parts[2]
    else:
        y = re.search(r"\b(18|19|20|21)\d{2}\b", body)
        year = int(y.group(0)) if y else None
        title = body
    arxiv = None
    um = ARXIV_RE.search(url)
    if um:
        arxiv = um.group(1).lower()
    return {
        "raw": raw, "authors": authors, "year": year, "title": title,
        "norm_authors": clean_text(authors), "norm_title": clean_text(title),
        "url": url, "arxiv_id": arxiv
    }

def build_records(data):
    queries, catalogue = [], {}
    parse_failures = []
    for collection in data.get("collections", []):
        cid = collection.get("collection_id")
        for j, item in enumerate(collection.get("citations", [])):
            qid = f"{cid}::{item.get('citation_number', j+1)}"
            inp = parse_citation(item.get("corrupted_citation", ""))
            gold = parse_citation(item.get("original_citation", ""))
            if not inp["norm_title"] or not gold["norm_title"]:
                parse_failures.append({"query_id": qid, "collection_id": cid,
                                       "input": item.get("corrupted_citation", ""),
                                       "gold": item.get("original_citation", "")})
                continue
            target_id = "rec_" + str(abs(hash(gold["raw"])))
            # Stable catalogue key independent of Python's randomized hash.
            import hashlib
            target_id = "rec_" + hashlib.sha1(gold["raw"].encode("utf-8")).hexdigest()[:12]
            catalogue[target_id] = {**gold, "record_id": target_id}
            queries.append({
                "query_id": qid, "collection_id": cid, "topic": collection.get("topic"),
                "input": inp, "target_id": target_id,
                "label": item.get("ground_truth_label"),
                "severity": item.get("error_severity", "none"),
                "error_type": item.get("error_type", "none"),
                "changes": item.get("changes", "")
            })
    return queries, list(catalogue.values()), parse_failures

def score_exact(q, c):
    return 100.0 if (q["norm_title"] == c["norm_title"] and
                     q["norm_authors"] == c["norm_authors"] and
                     q["year"] == c["year"]) else 0.0

def score_title(q, c):
    return float(fuzz.ratio(q["norm_title"], c["norm_title"]))

def score_weighted(q, c):
    title = score_title(q, c)
    authors = float(fuzz.ratio(q["norm_authors"], c["norm_authors"])) if q["norm_authors"] and c["norm_authors"] else 50.0
    if q["year"] is None or c["year"] is None:
        year = 50.0
    elif q["year"] == c["year"]:
        year = 100.0
    elif abs(q["year"] - c["year"]) == 1:
        year = 50.0
    else:
        year = 0.0
    if q["arxiv_id"] and c["arxiv_id"]:
        identifier = 100.0 if q["arxiv_id"] == c["arxiv_id"] else 0.0
    else:
        identifier = 50.0
    return 0.60*title + 0.25*authors + 0.10*year + 0.05*identifier

def rank_candidates(q, catalogue, method):
    fn = {"M1_exact": score_exact, "M2_title_fuzzy": score_title,
          "M3_weighted_fuzzy": score_weighted}[method]
    scored = [(c["record_id"], fn(q, c)) for c in catalogue]
    scored.sort(key=lambda x: (-x[1], x[0]))
    # Strict exact matching abstains when no candidate satisfies all fields;
    # zero-score catalogue entries are not treated as meaningful retrievals.
    if method == "M1_exact":
        scored = [item for item in scored if item[1] == 100.0]
    return scored

def evaluate_retrieval(ranked, target_id):
    ranks = [i+1 for i, (rid, _) in enumerate(ranked) if rid == target_id]
    rank = ranks[0] if ranks else None
    return {"hit_at_1": int(rank == 1), "hit_at_5": int(rank is not None and rank <= 5),
            "rr": 1.0/rank if rank else 0.0, "target_rank": rank}

def records_to_frame(queries, catalogue):
    return pd.DataFrame([{
        "query_id": q["query_id"], "collection_id": q["collection_id"],
        "topic": q["topic"], "input": q["input"]["raw"], "target_id": q["target_id"],
        "label": q["label"], "severity": q["severity"], "error_type": q["error_type"],
        "changes": q["changes"]
    } for q in queries])
