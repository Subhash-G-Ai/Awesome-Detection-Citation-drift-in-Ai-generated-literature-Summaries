# Data instructions

The raw benchmark is downloaded at runtime from:

https://raw.githubusercontent.com/FirstPrinciplesLabs/citecheck/main/dataset/corruption_metadata.json

Do not manually edit the downloaded JSON. Record the download date and Git commit/hash if you later pin a repository revision.

Input to methods: `corrupted_citation` only.

Evaluation-only fields: `original_citation`, `ground_truth_label`, `error_severity`, `error_type`, `changes`, `collection_id` (the latter is used only to construct a group split).

The catalogue is formed from unique parsed `original_citation` records. The paired original record is the retrieval target for evaluation, not a feature supplied to the matching score.
