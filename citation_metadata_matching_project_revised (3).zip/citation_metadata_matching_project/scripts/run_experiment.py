import argparse, json, hashlib, platform, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import requests
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import GroupShuffleSplit
from sklearn.metrics import (f1_score, precision_score, recall_score,
                             confusion_matrix, classification_report)
from matching import build_records, rank_candidates, evaluate_retrieval

DATA_URL = "https://raw.githubusercontent.com/FirstPrinciplesLabs/citecheck/main/dataset/corruption_metadata.json"
METHODS = ["M1_exact", "M2_title_fuzzy", "M3_weighted_fuzzy"]

def ensure_data(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        r = requests.get(DATA_URL, timeout=90)
        r.raise_for_status()
        path.write_bytes(r.content)
    return path

def binary_gold(label):
    return 1 if label == "valid" else 0

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/corruption_metadata.json")
    ap.add_argument("--out", default="results")
    args = ap.parse_args()
    data_path, out = Path(args.data), Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    ensure_data(data_path)
    raw = data_path.read_bytes()
    data = json.loads(raw)
    queries, catalogue, failures = build_records(data)
    if not queries:
        raise RuntimeError("No parseable query records. Inspect dataset schema and parser.")
    qdf = pd.DataFrame([{"query_id":q["query_id"],"collection_id":q["collection_id"],
                         "label":q["label"],"severity":q["severity"]} for q in queries])
    groups = qdf["collection_id"].to_numpy()
    splitter = GroupShuffleSplit(n_splits=1, test_size=0.30, random_state=42)
    dev_idx, test_idx = next(splitter.split(qdf, groups=groups))
    dev_ids, test_ids = set(qdf.iloc[dev_idx].query_id), set(qdf.iloc[test_idx].query_id)
    dev_groups = set(qdf.iloc[dev_idx].collection_id)
    test_groups = set(qdf.iloc[test_idx].collection_id)
    assert not (dev_groups & test_groups), "Collection leakage detected"
    split_info = {
        "seed":42, "test_size":0.30, "dev_query_count":len(dev_ids),
        "test_query_count":len(test_ids), "dev_collections":sorted(dev_groups),
        "test_collections":sorted(test_groups), "group_overlap":sorted(dev_groups & test_groups),
        "catalogue_size":len(catalogue)
    }
    (out/"splits.json").write_text(json.dumps(split_info, indent=2))
    if failures:
        pd.DataFrame(failures).to_csv(out/"parse_failures.csv", index=False)

    query_by_id = {q["query_id"]:q for q in queries}
    cache = {}
    for q in queries:
        for method in METHODS:
            cache[(q["query_id"],method)] = rank_candidates(q["input"], catalogue, method)

    # Tune M2/M3 thresholds on development only.
    thresholds = {"M1_exact": 99.999}
    threshold_rows = []
    grid = np.arange(50, 101, 1)
    for method in ["M2_title_fuzzy","M3_weighted_fuzzy"]:
        best = None
        for th in grid:
            yt, yp = [], []
            for qid in dev_ids:
                q = query_by_id[qid]
                yt.append(binary_gold(q["label"]))
                best_score = cache[(qid,method)][0][1]
                yp.append(int(best_score >= th))
            score = f1_score(yt, yp, average="macro", zero_division=0)
            threshold_rows.append({"method":method,"threshold":int(th),"dev_macro_f1":score})
            candidate = (score, int(th))
            if best is None or candidate > best:
                best = candidate
        thresholds[method] = best[1]

    pred_rows = []
    for q in queries:
        qid = q["query_id"]
        split = "dev" if qid in dev_ids else "test"
        for method in METHODS:
            ranked = cache[(qid,method)]
            best_score = ranked[0][1] if ranked else 0.0
            threshold = thresholds[method]
            pred = int(best_score >= threshold)
            ret = evaluate_retrieval(ranked, q["target_id"])
            pred_rows.append({
                "query_id":qid,"collection_id":q["collection_id"],"topic":q["topic"],
                "split":split,"method":method,"gold_label":q["label"],
                "gold_binary":binary_gold(q["label"]),"severity":q["severity"],
                "error_type":q["error_type"],"best_score":best_score,
                "threshold":threshold,"predicted_valid":pred,
                "target_rank":ret["target_rank"],"hit_at_1":ret["hit_at_1"],
                "hit_at_5":ret["hit_at_5"],"reciprocal_rank":ret["rr"]
            })
    pdf = pd.DataFrame(pred_rows)
    pdf.to_csv(out/"predictions.csv", index=False)
    pd.DataFrame(threshold_rows).to_csv(out/"threshold_sensitivity.csv", index=False)

    metrics = {"dataset_citations_in_json":sum(len(c.get("citations",[])) for c in data.get("collections",[])),
               "parseable_queries":len(queries),"parse_failures":len(failures),
               "catalogue_size":len(catalogue),"thresholds_selected_on_dev":thresholds,
               "test":{}}
    for method in METHODS:
        d = pdf[(pdf.split=="test") & (pdf.method==method)]
        y, p = d.gold_binary.tolist(), d.predicted_valid.tolist()
        metrics["test"][method] = {
            "macro_f1":float(f1_score(y,p,average="macro",zero_division=0)),
            "precision_valid":float(precision_score(y,p,zero_division=0)),
            "recall_valid":float(recall_score(y,p,zero_division=0)),
            "hit_at_1":float(d.hit_at_1.mean()),
            "hit_at_5":float(d.hit_at_5.mean()),
            "mrr":float(d.reciprocal_rank.mean()),
            "valid_false_reject_rate":float(((d.gold_binary==1)&(d.predicted_valid==0)).sum()/max(1,(d.gold_binary==1).sum())),
            "corrupted_false_accept_rate":float(((d.gold_binary==0)&(d.predicted_valid==1)).sum()/max(1,(d.gold_binary==0).sum())),
            "test_count":int(len(d))
        }
    (out/"metrics.json").write_text(json.dumps(metrics,indent=2))
    # Threshold sensitivity plot, development partition only.
    ts = pd.DataFrame(threshold_rows)
    fig, ax = plt.subplots(figsize=(7,4))
    for method in ["M2_title_fuzzy","M3_weighted_fuzzy"]:
        sub=ts[ts.method==method]
        ax.plot(sub.threshold,sub.dev_macro_f1,marker="o",label=method)
    ax.set_xlabel("Similarity threshold")
    ax.set_ylabel("Development macro-F1")
    ax.set_title("Threshold sensitivity (development split)")
    ax.legend()
    fig.tight_layout()
    fig.savefig(out/"threshold_sensitivity.png",dpi=200)
    plt.close(fig)
    # Label/severity analysis and error rows on test.
    test = pdf[pdf.split=="test"]
    breakdown = test.groupby(["method","gold_label"],dropna=False).apply(
        lambda g: pd.Series({
            "count": len(g),
            "correct_binary_rate": float((g.gold_binary == g.predicted_valid).mean())
        }), include_groups=False
    ).reset_index()
    breakdown.to_csv(out/"label_breakdown.csv",index=False)
    errors = test[test.gold_binary != test.predicted_valid].copy()
    errors.to_csv(out/"error_analysis.csv",index=False)
    run_meta = {
        "python":sys.version,"platform":platform.platform(),
        "pandas":pd.__version__,"numpy":np.__version__,
        "dataset_url":DATA_URL,"dataset_sha256":hashlib.sha256(raw).hexdigest(),
        "run_unix_time":time.time(),"seed":42
    }
    (out/"run_metadata.json").write_text(json.dumps(run_meta,indent=2))
    print("RUN COMPLETE")
    print(json.dumps(metrics,indent=2))
    print(f"Saved outputs to: {out.resolve()}")

if __name__ == "__main__":
    main()
