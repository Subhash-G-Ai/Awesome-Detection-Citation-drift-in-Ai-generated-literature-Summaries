import json, platform, sys, os
from pathlib import Path
report = {
    "python": sys.version,
    "platform": platform.platform(),
    "cpu_count": os.cpu_count(),
}
try:
    import psutil
    report["ram_gb"] = round(psutil.virtual_memory().total / (1024**3), 2)
except Exception as e:
    report["ram_check_error"] = str(e)
for pkg in ["pandas","numpy","rapidfuzz","sklearn","matplotlib","requests"]:
    try:
        mod = __import__(pkg)
        report[pkg] = getattr(mod, "__version__", "imported")
    except Exception as e:
        report[pkg] = "ERROR: " + str(e)
Path("results").mkdir(exist_ok=True)
Path("results/environment.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
