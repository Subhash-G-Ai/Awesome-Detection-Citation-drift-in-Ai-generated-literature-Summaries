# Frozen experiment protocol (version 1.0)

## Task definition

For each citation query, rank candidate reference records from a fixed catalogue and classify the query as `valid` or `corrupted` using a method-specific similarity score and threshold.

## Dataset fields

- Detector input: `corrupted_citation`.
- Catalogue record: parsed `original_citation`.
- Evaluation target: paired original citation's canonical catalogue ID.
- Binary gold label: `valid` = 1; both hallucination classes = 0.
- Group: `collection_id`.
- Additional analysis labels: `ground_truth_label`, `error_severity`, `error_type`.

Gold metadata and target IDs are never passed into a method's scoring function.

## Methods

M1 exact-field baseline: score 100 only when normalized title, normalized author string and year all match; otherwise 0. Predict valid on exact match. Ties are handled deterministically.

M2 title-only fuzzy baseline: RapidFuzz normalized title similarity (0–100). Tune threshold on development macro-F1.

M3 weighted multi-field fuzzy: 0.60 title similarity + 0.25 author similarity + 0.10 year score + 0.05 identifier score. Year score is 100 for exact year, 50 for a one-year difference, 0 otherwise. Identifier score is 100 for equal extracted arXiv IDs, 0 for conflicting IDs, and 50 if one/both are absent. These weights are heuristics fixed before test evaluation.

## Split

GroupShuffleSplit with `collection_id`, test_size=0.30, random_state=42. Development data is the complement. Verify zero group overlap. If the library split produces a class imbalance, report it; do not silently resample.

## Threshold selection

For M2 and M3, choose the threshold from 50, 55, ..., 95 maximizing development macro-F1 for binary valid/corrupted. Ties choose the higher threshold. M1 has no tuned threshold.

## Metrics

Primary: binary macro-F1, precision, recall, valid false-accept rate and corrupted false-reject rate.

Retrieval: Hit@1, Hit@5, MRR using the paired original record as the target. Report candidate catalogue size and parse coverage.

Deep analysis: threshold sensitivity, performance by `ground_truth_label`/severity and manually inspected error cases. Do not claim statistical significance unless a valid inferential procedure is added and justified.

## Threats to validity

- Closed catalogue differs from open-world bibliographic retrieval.
- The benchmark has controlled corruption patterns and may not represent naturally occurring citation errors.
- Parsing citation strings can fail or ambiguously interpret author/year/title.
- Similarity weights are heuristic.
- The dataset's paired original is treated as the target; correctness of all original records is inherited from the benchmark.
- Catalogue records may contain duplicates or near-duplicates.
- Results do not assess semantic support of cited claims.

## Change control

Any change to parsing, split, weights, threshold grid, labels or metric must be recorded in `PROTOCOL_CHANGELOG.md` with date, reason and whether test data had already been inspected.
