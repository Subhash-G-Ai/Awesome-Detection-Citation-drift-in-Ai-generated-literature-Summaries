# Baseline and data validation checklist

Complete this using actual Colab output.

- [ ] Python and dependency versions saved.
- [ ] Dataset downloaded from the stated source; SHA-256 recorded.
- [ ] JSON has `collections`; every collection has `collection_id` and `citations`.
- [ ] Input and evaluation fields exist.
- [ ] Parsed query and target counts reported; parse failures retained in a failure file.
- [ ] Catalogue IDs are unique; duplicate/near-duplicate handling documented.
- [ ] Every query target exists in the candidate catalogue.
- [ ] Group split has zero `collection_id` overlap.
- [ ] All methods score identical candidate records.
- [ ] Gold labels and paired target IDs are not used in method scoring.
- [ ] Thresholds are selected on development only.
- [ ] Test metrics are calculated only after protocol freeze.
- [ ] Unit tests for parser, similarity and split pass.
- [ ] Outputs are reproducible with seed 42.
- [ ] Actual logs, CSVs and plots are saved.
