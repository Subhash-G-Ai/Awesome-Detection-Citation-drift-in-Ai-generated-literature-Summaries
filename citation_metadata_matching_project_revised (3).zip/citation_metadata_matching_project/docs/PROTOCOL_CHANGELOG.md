# Protocol changelog

| Version | Date | Change | Reason | Test split already inspected? |
|---|---|---|---|---|
| 1.0 | 2026-11-14 | Initial protocol | Pre-experiment specification | No |

Add a row before making any methodological change. Never rewrite earlier decisions to hide a deviation.
