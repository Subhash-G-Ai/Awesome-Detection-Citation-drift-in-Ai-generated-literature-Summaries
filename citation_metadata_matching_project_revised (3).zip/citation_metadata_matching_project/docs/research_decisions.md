# Research decisions and provenance

## Review-to-experiment bridge

Prior review topic: detection of citation drift in AI-generated literature summaries. The review discusses bibliographic metadata corruption and the need to distinguish record existence/metadata consistency from semantic claim-support verification.

## Selected project question

**Primary RQ:** Under a fixed closed catalogue of reference records, how do exact-field, title-only fuzzy, and weighted multi-field fuzzy matching compare in recovering the paired reference record from valid and corrupted citation strings?

**Supporting RQ1:** Does multi-field matching improve top-1 recovery over title-only matching, particularly for minor metadata corruption?

**Supporting RQ2:** How sensitive are binary valid-versus-corrupted decisions to the classification threshold?

## Scope boundary

This experiment is *not* open-world discovery, DOI resolution, plagiarism detection, or entailment verification. It does not establish whether a cited work supports a generated statement. Its catalogue is built from the benchmark's original reference records.

## Candidate contribution

A controlled, reproducible comparison and error analysis of simple metadata matching strategies under benchmark-provided corruption types. Novelty is not claimed. This is a course-scale comparative study (pathway B).

## Evidence status

- VERIFIED from the dataset schema page: 42 collections, 982 citations, three labels, and the distinction between corrupted input and evaluation metadata. See https://github.com/FirstPrinciplesLabs/citecheck/blob/main/dataset/SCHEMA.md
- VERIFIED from the companion paper landing page: CiteCheck introduces a 982-citation physics benchmark and retrieval-grounded citation verification. See https://aclanthology.org/2026.groundlm-1.58/
- INFERRED: the benchmark is suitable for a closed-catalogue metadata-recovery comparison. This is tested by parsing and schema checks in the notebook.
- UNKNOWN until execution: parse coverage, duplicate catalogue rate, group split composition, method metrics, failure cases, actual runtime and memory.

## Constraints and decisions

- Same query set and same candidate catalogue for all methods.
- `collection_id` is the group split key.
- Thresholds selected only on development data.
- Test data is not used for threshold selection.
- Gold target and labels are evaluator-only.
- All scores and paper conclusions must be populated from genuine outputs.
