# Datasets

## Citation Hallucination Benchmark

A benchmark containing citation-backed generations from multiple LLMs and domains, with references manually verified against scholarly databases.

Source: https://github.com/Zerichen/Citation-Hallucination

## Citation Drift Evaluation Data

The citation-drift study evaluates 240 conversations across four LLaMA models using 36 authentic scientific papers from six domains.

Source: https://aclanthology.org/2025.wasp-main.20/

## LLM-Generated Scientific References

A 2026 study reports 74,196 generated BibTeX references from nine LLMs and 127,063 references extracted from 3,541 published papers.

Source: https://doi.org/10.3390/data11050122
