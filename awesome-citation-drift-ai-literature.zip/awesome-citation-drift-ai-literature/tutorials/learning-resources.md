# Tutorials and Learning Resources

## ACL Anthology: Citation Drift

https://aclanthology.org/2025.wasp-main.20/

A research-oriented resource explaining citation drift and evaluating reference stability in multi-turn LLM conversations.

## Crossref Documentation

https://www.crossref.org/documentation/

Useful for understanding DOI registration and scholarly metadata retrieval.

## OpenAlex Documentation

https://docs.openalex.org/

Useful for learning how to query open scholarly metadata.

## Semantic Scholar API

https://www.semanticscholar.org/product/api

Useful for programmatic paper and citation discovery.

## PubMed

https://pubmed.ncbi.nlm.nih.gov/

Useful for biomedical literature searching and verification.
