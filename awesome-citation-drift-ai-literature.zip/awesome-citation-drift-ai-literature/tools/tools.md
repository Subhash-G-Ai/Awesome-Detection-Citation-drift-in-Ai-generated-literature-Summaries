# Tools and Libraries

| Tool | Purpose | Source |
|---|---|---|
| Crossref | DOI and scholarly metadata verification | https://www.crossref.org/ |
| OpenAlex | Open scholarly metadata search | https://openalex.org/ |
| Semantic Scholar | Paper and citation discovery | https://www.semanticscholar.org/ |
| Google Scholar | Exact-title and author/title verification | https://scholar.google.com/ |
| PubMed | Biomedical literature verification | https://pubmed.ncbi.nlm.nih.gov/ |

## Recommended Verification Workflow

1. Extract the title, authors, year, venue, and identifier from an AI-generated citation.
2. Resolve the DOI, arXiv ID, or PMID when one is provided.
3. Cross-check the metadata against an official publisher or repository.
4. Search the exact title independently.
5. Compare authors, year, venue, volume/pages, and identifier.
6. For claim-citation support, inspect the source abstract or full text and compare it with the generated claim.
