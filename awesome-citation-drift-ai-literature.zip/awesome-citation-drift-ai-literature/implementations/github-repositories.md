# GitHub Implementations

## Citation-Hallucination Benchmark

https://github.com/Zerichen/Citation-Hallucination

This repository provides a benchmark for citation hallucination in LLM-generated text, including validation data and citation-checking logic.

## CheckIfExist

The CheckIfExist project describes an open-source reference verification approach using Crossref, Semantic Scholar, and OpenAlex.

Project/paper: https://arxiv.org/abs/2602.15871
